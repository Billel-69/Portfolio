[]: # Title: README
[]: # Description: README file for the game

pip install pygame

to launch the game, run the following command:
python3 main.py
```